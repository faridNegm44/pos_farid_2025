<?php

namespace App\Helpers;
use App\Models\Back\FinancialYears;

class GetFinancialYearHelper
{
    //public static function getFinancialYear(){
    //    return FinancialYears::where('status', 1)->first();
    //}
}
