<?php

namespace App\Models\Back;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TasweaReasons extends Model
{
    protected $table = 'taswea_reasons';
    protected $fillable = ['name'];

}
