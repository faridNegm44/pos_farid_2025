<!--Horizontal-main -->
<div class="sticky">
    <div class="horizontal-main hor-menu clearfix side-header bg bg-primary-gradient" style="background-image: linear-gradient(to left, #0698bf 0, #6c8895 100%) !important;">
        <div class="horizontal-mainwrapper container clearfix">
            <!--Nav-->
            <nav class="horizontalMenu clearfix">
                <ul class="horizontalMenu-list bg bg-primary-gradient" style="background-image: linear-gradient(to left, #0698bf 0, #6c8895 100%) !important;">
                    

                  
                    <li aria-haspopup="true"><a href="<?php echo e(url('products')); ?>" class="sub-icon text-light">الأصناف / المخازن<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">
                            <li aria-haspopup="true"><a href="<?php echo e(url('products')); ?>" class="slide-item text-dark">الأصناف</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('productsCategories')); ?>" class="slide-item text-dark">أقسام الأصناف</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('units')); ?>" class="slide-item text-dark">وحدات الأصناف</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('companies')); ?>" class="slide-item text-dark">شركات الأصناف</a></li>
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('stores')); ?>" class="slide-item text-dark">المخازن</a></li>
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('transfer_between_stores')); ?>" class="slide-item text-dark">تحويلات الأصناف بين المخازن</a></li>
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('taswea_products')); ?>" class="slide-item text-dark">تسوية كميات الأصناف</a></li>
                            
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('products/report')); ?>" class="slide-item text-dark">تقرير عن حركة صنف</a></li>
                        </ul>
                    </li>

                    <li aria-haspopup="true"><a href="<?php echo e(url('clients')); ?>" class="sub-icon text-light">العملاء / الموردين<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">
                            <li aria-haspopup="true"><a href="<?php echo e(url('clients')); ?>" class="slide-item text-dark">العملاء</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers')); ?>" class="slide-item text-dark">الموردين</a></li>

                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('clients/report')); ?>" class="slide-item text-dark">تقرير عن حركة عميل</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('clients/report/account_statement')); ?>" class="slide-item text-dark">كشف حساب عميل</a></li>

                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers/report')); ?>" class="slide-item text-dark">تقرير عن حركة مورد</a></li>                            
                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers/report/account_statement')); ?>" class="slide-item text-dark">كشف حساب مورد</a></li>                            
                            
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('taswea_client_supplier')); ?>" class="slide-item text-dark">تسوية رصيد عميل / مورد</a></li>                            
                        </ul>
                    </li>
                    
                    <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills/create')); ?>" class="sub-icon text-light">الحسابات<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">         
                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills/create')); ?>" class="slide-item text-dark">أجراء معاملة في الخزينة المالية</a></li>                   
                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills')); ?>" class="slide-item text-dark">معاملات الخزينة المالية</a></li>
                            
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('expenses')); ?>" class="slide-item text-dark">المصروفات</a></li>
                            
                            
                            
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('financial_treasury')); ?>" class="slide-item text-dark">الخزائن المالية</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('transfer_between_storages')); ?>" class="slide-item text-dark">التحويل من خزنة لآخري</a></li>
                            
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('expenses/report')); ?>" class="slide-item text-dark">تقرير عن المصروفات</a></li>

                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills/report')); ?>" class="slide-item text-dark">تقرير عن حركة الخزائن المالية</a></li>
                        </ul>
                    </li>

                    <li aria-haspopup="true"><a href="<?php echo e(url('sales/create')); ?>" class="sub-icon text-light">المبيعات<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">                                          
                            <li aria-haspopup="true"><a href="<?php echo e(url('/sales/create')); ?>" class="slide-item text-dark">إضافة فاتورة مبيعات</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('/sales')); ?>" class="slide-item text-dark">فواتير المبيعات</a></li>

                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('sales_return')); ?>" class="slide-item text-dark">فواتير مرتجع المبيعات</a></li>
                            

                            
                        </ul>
                    </li>

                    <li aria-haspopup="true"><a href="<?php echo e(url('purchases/create')); ?>" class="sub-icon text-light">المشتريات<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">
                            <li aria-haspopup="true"><a href="<?php echo e(url('/purchases/create')); ?>" class="slide-item text-dark">إضافة فاتورة مشتريات</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('/purchases')); ?>" class="slide-item text-dark">فواتير المشتريات</a></li>
                            
                            <hr class="navbar_hr"/>
                            <li aria-haspopup="true"><a href="<?php echo e(url('purchases_return')); ?>" class="slide-item text-dark">فواتير مرتجع المشتريات</a></li>

                            
                            
                            
                        </ul>
                    </li>

                    <li aria-haspopup="true"><a href="<?php echo e(url('users')); ?>" class="sub-icon text-light">الموظفين<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">
                            <li aria-haspopup="true"><a href="<?php echo e(url('/users')); ?>" class="slide-item text-dark">مستخدمين النظام</a></li>
                        </ul>
                    </li>

                    <li aria-haspopup="true"><a href="<?php echo e(url('settings')); ?>" class="sub-icon text-light">الإعدادات<i class="fe fe-chevron-down horizontal-icon"></i></a>
                        <ul class="sub-menu">
                            <li aria-haspopup="true"><a href="<?php echo e(url('financialYears')); ?>" class="slide-item text-dark">السنوات المالية</a></li>
                            <li aria-haspopup="true"><a href="<?php echo e(url('/settings')); ?>" class="slide-item text-dark">إعدادات البرنامج</a></li>
                            
                        </ul>
                    </li>


                </ul>
            </nav>
            <!--Nav-->
        </div>
    </div>
</div>
<!--Horizontal-main --><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/layouts/navbar.blade.php ENDPATH**/ ?>