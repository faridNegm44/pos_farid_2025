<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        
        <div class="modal-body">
            <form class="" id="form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="res_id" value="" />               
                
                <div class="pd-30 pd-sm-40 bg-gray-100">
                  <h5 style="text-decoration: underline;font-weight: bold;">بيانات أساسية</h5>
                  <div class="row row-xs">
                    <div class="col-lg-3 col-md-6 col-12">
                      <label for="nameAr">إسم الصنف بالعربية</label>
                      <i class="fas fa-star require_input"></i>
                      <div>
                          <input type="text" class="form-control dataInput" placeholder="إسم الصنف بالعربية" id="nameAr" name="nameAr" data-autofocus >
                      </div>
                      <bold class="text-danger" id="errors-nameAr" style="display: none;"></bold>
                  </div>                        

                  <div class="col-lg-3 col-md-6 col-12">
                      <label for="nameEn">إسم الصنف بالأجنبية</label>
                      <div>
                          <input type="text" class="form-control dataInput" placeholder="إسم الصنف بالأجنبية" id="nameEn" name="nameEn" >
                      </div>
                      <bold class="text-danger" id="errors-nameEn" style="display: none;"></bold>
                  </div>

                    <div class="col-lg-1 col-md-6 col-12">
                        <label for="shortCode">ك مختصر</label>
                        <div>
                            <input type="text" class="form-control dataInput" placeholder="ك مختصر" id="shortCode" name="shortCode" >
                        </div>
                        <bold class="text-danger" id="errors-shortCode" style="display: none;"></bold>
                    </div>                        
                    
                    <div class="col-lg-2 col-md-6 col-12">
                        <label for="natCode">ك دولي</label>
                        <div>
                            <input type="text" class="form-control dataInput" placeholder="ك دولي" id="natCode" name="natCode" >
                        </div>
                        <bold class="text-danger" id="errors-natCode" style="display: none;"></bold>
                    </div>                        

                    <div class="col-lg-1 col-md-6 col-12">
                      <label for="status">حالة الصنف</label>
                        <div>    
                            <select  name="status" class="status selectize" id="status">
                                <option value="1">نشط</option>
                                <option value="0">معطل</option>
                            </select>
                        </div>
                      <bold class="text-danger" id="errors-status" style="display: none;"></bold>
                    </div>  

                    <div class="col-lg-2 col-md-6 col-12">
                      <label for="image">صورة الصنف</label>
                      <div>
                          <input type="file" class="form-control dataInput" placeholder="صورة الصنف" id="image" name="image" >
                          <input type="hidden" class="dataInput" id="image_hidden" name="image_hidden" >
                      </div>
                      <bold class="text-danger" id="errors-image" style="display: none;"></bold>
                    </div> 

                    <div class="col-lg-2 col-md-6 col-12">
                      <label for="store">المخزن</label>
                      <i class="fas fa-star require_input"></i>
                      <div>    
                          <select  name="store" class="store selectize" id="store">
                            <option value="" selected>المخزن</option>                              
                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($store->id); ?>" <?php echo e($index == 0 ? 'selected' : ''); ?>><?php echo e($store->name); ?></option>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <bold class="text-danger" id="errors-store" style="display: none;"></bold>
                    </div>                        

                    <div class="col-lg-2 col-md-6 col-12">
                      <label for="category">قسم الصنف</label>
                      <div>    
                          <select  name="category" class="category selectize" id="category">
                            <option value="" selected>قسم الصنف</option>                              
                            <?php $__currentLoopData = $productCategoys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($categoy->id); ?>"><?php echo e($categoy->name); ?></option>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <bold class="text-danger" id="errors-category" style="display: none;"></bold>
                    </div>                        

                    <div class="col-lg-2 col-md-6 col-12">
                      <label for="company">الشركة المصنعة</label>
                      <div>    
                          <select  name="company" class="company selectize" id="company">
                            <option value="" selected>الشركة المصنعة</option>
                            <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <bold class="text-danger" id="errors-company" style="display: none;"></bold>
                    </div>                                            

                    <div class="col-lg-2 col-md-6 col-12">
                      <label for="stockAlert">الحد الأدني للطلب</label>
                      <div>
                          <input type="number" class="form-control dataInput" placeholder="الحد الأدني للطلب" id="stockAlert" name="stockAlert" min="0">
                      </div>
                      <bold class="text-danger" id="errors-stockAlert" style="display: none;"></bold>
                    </div> 

                    <div class="col-lg-4 col-md-6 col-12">
                      <label for="desc">وصف الصنف</label>
                      <div>
                          <input type="text" class="form-control dataInput" placeholder="وصف المنتج" id="desc" name="desc" >
                      </div>
                      <bold class="text-danger" id="errors-desc" style="display: none;"></bold>
                    </div>   
                  </div>
                  <hr>


                  <h5 style="text-decoration: underline;font-weight: bold;">بيانات السعر والوحدات</h5>
                  <div class="row row-xs">
                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                      <label for="bigUnit">الوحدة الكبري</label>
                      <div>    
                          <select  name="bigUnit" class="bigUnit selectize" id="bigUnit">
                            <option value="" selected>الوحدة الكبري</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <bold class="text-danger" id="errors-bigUnit" style="display: none;"></bold>
                    </div>                        

                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                      <label for="smallUnit">الوحدة الصغري</label>
                      <div>    
                          <select  name="smallUnit" class="smallUnit selectize" id="smallUnit">
                            <option value="" selected>الوحدة الصغري</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <bold class="text-danger" id="errors-smallUnit" style="display: none;"></bold>
                    </div> 

                    <div class="col-lg-2 col-md-6 col-md-4 col-12" id="small_unit_numbers_section">
                      <label for="small_unit_numbers">عدد وحدات الصغري</label>
                      <i class="fas fa-info-circle text-primary" data-bs-toggle="tooltip" title="عدد الوحدات الصغرى التي تُكوِّن وحدة كبرى واحدة من هذا المنتج (مثال: 1 كرتونة = 12 علبة)"></i>
                      <i class="fas fa-star require_input"></i>

                      <div>
                          <input type="number" class="form-control dataInput" placeholder="عدد وحدات الصغري" id="small_unit_numbers" name="small_unit_numbers" min="1">
                      </div>
                      <bold class="text-danger" id="errors-small_unit_numbers" style="display: none;"></bold>
                    </div>  

                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                        <label for="last_cost_price_small_unit">س الشراء</label>
                        <div>
                            <input type="number" class="form-control dataInput" placeholder="س الشراء" id="last_cost_price_small_unit" name="last_cost_price_small_unit" min="0">
                        </div>
                        <bold class="text-danger" id="errors-last_cost_price_small_unit" style="display: none;"></bold>
                    </div>                        

                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                      <label for="sell_price_small_unit">سعر البيع</label>
                      <i class="fas fa-info-circle text-primary" data-bs-toggle="tooltip" title="هذا السعر مخصص لبيع أصغر وحدة ممكنة من هذا المنتج، مثل العبوة أو القطعة أو الجرام بحسب طبيعة المنتج"></i>

                      <div>
                          <input type="number" class="form-control dataInput" placeholder="سعر البيع" id="sell_price_small_unit" name="sell_price_small_unit" min="0">
                      </div>
                      <bold class="text-danger" id="errors-sell_price_small_unit" style="display: none;"></bold>
                    </div>  

                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                      <label for="tax">الضريبة</label>
                      <div>
                          <input type="number" class="form-control dataInput" placeholder="الضريبة" id="tax" name="tax" min="0">
                      </div>
                      <bold class="text-danger" id="errors-tax" style="display: none;"></bold>
                    </div>   
                    
                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                      <label for="discountPercentage">أقصي نسبة خصم %</label>
                      <div>
                          <input type="number" class="form-control dataInput" placeholder="أقصي نسبة خصم %" id="discountPercentage" name="discountPercentage" min="0">
                      </div>
                      <bold class="text-danger" id="errors-discountPercentage" style="display: none;"></bold>
                    </div>
                  
                    <div class="col-lg-2 col-md-6 col-md-4 col-12">
                        <label for="max_sale_quantity">أقصي كمية بيع</label>
                        <div>
                            <input type="number" class="form-control dataInput" placeholder="أقصي كمية بيع" id="max_sale_quantity" name="max_sale_quantity" min="0">
                        </div>
                        <bold class="text-danger" id="errors-max_sale_quantity" style="display: none;"></bold>
                    </div>

                    <div class="col-lg-2 col-md-6 col-12" id="firstPeriodCountSection">
                      <label for="firstPeriodCount">رصيد أول مدة</label>
                      <i class="fas fa-info-circle text-primary" data-bs-toggle="tooltip" title="يرجى إدخال رصيد أول المدة لهذا الصنف بعدد الوحدات الصغرى فقط، مثلًا: إذا كانت الكرتونة تحتوي على 12 قطعة، يتم إدخال 12."></i>

                      <div>
                          <input type="number" class="form-control dataInput" placeholder="رصيد أول مدة" id="firstPeriodCount" name="firstPeriodCount" min="0">
                      </div>
                      <bold class="text-danger" id="errors-firstPeriodCount" style="display: none;"></bold>
                    </div>  
                  </div>
                  
                  
                  
                  
                  
                  
                  




                </div> 

                <div class="modal-footer bg bg-dark">                                               
                    <button type="button" id="save" class="btn btn-success" style="display: none;">
                      حفظ
                      <span class="spinner-border spinner-border-sm spinner_request" role="status" aria-hidden="true"></span>
                    </button>

                    <button type="button" id="update" class="btn btn-success" style="display: none;">
                      تعديل
                      <span class="spinner-border spinner-border-sm spinner_request2" role="status" aria-hidden="true"></span>
                    </button>
                    
                    <button id="closeModal" type="button" class="btn btn-light" data-dismiss="modal">اغلاق</button>
                </div> 

            </form>            
        </div>
      </div>
    </div>
</div>
<?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/products/form.blade.php ENDPATH**/ ?>