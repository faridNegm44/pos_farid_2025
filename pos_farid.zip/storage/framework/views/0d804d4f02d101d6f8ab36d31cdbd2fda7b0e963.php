<div class="text-center" style="font-size: 8px;margin-top: 30px;">
    DEV: <span style="font-weight: bold;text-decoration: underline;">Farid Negm</span>
    
</div><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/layouts/footer_report.blade.php ENDPATH**/ ?>