


<?php $__env->startSection('title'); ?>
    <?php echo e($pageNameAr); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        table.dataTable tbody td.sorting_1{
            background: transparent !important;
        }
        .itemsSearch{
            margin: 0 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>  
    <script>
        $(document).ready(function() {
            $('#example1').DataTable().destroy();
            $('#example1').DataTable({
                "paging": false, // تعطيل التقسيم
                "searching": true, // تفعيل البحث (اختياري)
                "ordering": true, // تفعيل الترتيب (اختياري)
                "info": false, // إخفاء معلومات الصفحة (اختياري)
                "order": [[0, 'asc']]
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- breadcrumb -->
        <div class="breadcrumb-header text-danger" style="display: block !important;text-align: center;margin-bottom: 15px;">
            <h4 class="content-title mb-5 my-auto"><?php echo e($pageNameAr); ?></h4>
        </div>
        <!-- breadcrumb -->

        <div style="margin-bottom: 10px;">
            <div>
                <?php if($supplier_id): ?>
                    <span class="itemsSearch">عميل: <?php echo e($results[0]->supplierName); ?></span>
                <?php endif; ?>
                <?php if($treasury_type): ?>
                    <span class="itemsSearch">نوع الحركة: <?php echo e($results[0]->treasury_type); ?></span>
                <?php endif; ?>
                <?php if($from): ?>
                    <span class="itemsSearch">تاريخ من: <?php echo e($from); ?></span>
                <?php endif; ?>
                <?php if($to): ?>
                    <span class="itemsSearch">تاريخ الي: <?php echo e($to); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center text-md-nowrap" id="example1">
                        <thead>
                            <tr>
                                
                                <th class="border-bottom-0" >تاريخ الحركة</th>
                                <th class="border-bottom-0" >تاريخ اخر</th>
                                <th class="border-bottom-0">خزينة الحركة</th>
                                <th class="border-bottom-0">نوع الحركة</th>
                                <th class="border-bottom-0">الجهة</th>
                                <th class="border-bottom-0">قيمة الحركة</th>
                                <th class="border-bottom-0">علي الجهة / لها</th>
                                <th class="border-bottom-0">مبلغ الخزينة بعد</th>
                                <th class="border-bottom-0" >مستخدم</th>
                                <th class="border-bottom-0">ملاحظات</th>
                            </tr>
                        </thead>                               
                        
                        <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <?php
                                    $type = '';

                                    if($result->treasury_type == 'اذن توريد نقدية'){
                                        $type = '#8ae3aa';
                                    }elseif($result->treasury_type == 'اذن صرف نقدية'){
                                        $type = '#de7df0';
                                    }elseif($result->treasury_type == 'رصيد اول عميل'){
                                        $type = '#fafafa';
                                    }
                                ?>


                                <tr style="background: <?php echo e($type); ?>;">
                                    
                                    <td>
                                        <?php echo e(Carbon\Carbon::parse($result->created_at)->format('d-m-Y')); ?>

                                        <span style="margin: 0 5px;display: block;"><?php echo e(Carbon\Carbon::parse($result->created_at)->format('h:i:s a')); ?></span>
                                    </td>
                                    <td>
                                        <?php if(Carbon\Carbon::parse($result->created_at)->format('d-m-Y') != Carbon\Carbon::parse($result->date)->format('d-m-Y')): ?>
                                            <span style="margin: 0 5px;"><?php echo e(Carbon\Carbon::parse($result->date)->format('d-m-Y')); ?></span>
                                        <?php endif; ?>                                        
                                    </td>
                                    <td><?php echo e($result->treasury_name); ?></td>
                                    <td><?php echo e($result->treasury_type); ?></td>
                                    <td><?php echo e($result->supplierName); ?></td>
                                    <td><?php echo e($result->amount_money); ?></td>
                                    <td><?php echo e($result->remaining_money); ?></td>
                                    <td><?php echo e($result->treasury_money_after); ?></td>
                                    <td><?php echo e($result->userName); ?></td>
                                    <td><?php echo e($result->notes); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/reports/suppliers/result.blade.php ENDPATH**/ ?>