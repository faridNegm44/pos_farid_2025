


<?php $__env->startSection('title'); ?>
    <?php echo e($pageNameAr); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        table.dataTable tbody td.sorting_1{
            background: transparent !important;
        }
        .itemsSearch{
            margin: 0 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>  
    <script>
        $(document).ready(function() {
            $('#example1').DataTable().destroy();
            $('#example1').DataTable({
                "paging": false, // تعطيل التقسيم
                "searching": true, // تفعيل البحث (اختياري)
                "ordering": true, // تفعيل الترتيب (اختياري)
                "info": false // إخفاء معلومات الصفحة (اختياري)
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- breadcrumb -->
        <div class="breadcrumb-header text-danger" style="display: block !important;text-align: center;margin-bottom: 15px;">
            <h4 class="content-title mb-5 my-auto"><?php echo e($pageNameAr); ?></h4>
        </div>
        <!-- breadcrumb -->

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center text-md-nowrap" id="example1">
                        <thead>
                            <tr>
                                <th class="border-bottom-0">كود الصنف</th>
                                <th class="border-bottom-0">اسم الصنف</th>
                                <th class="border-bottom-0">حد الطلب</th>
                                <th class="border-bottom-0">كمية الصنف حاليا</th>
                                <th class="border-bottom-0">المخزن</th>
                                <th class="border-bottom-0" >القسم</th>
                            </tr>
                        </thead>                               
                        
                        <tbody>
                            <?php $__currentLoopData = $supp_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    

                                <tr>
                                    <td><?php echo e($result->productId); ?></td>
                                    <td><?php echo e($result->nameAr); ?></td>
                                    <td><?php echo e($result->stockAlert); ?></td>                                    
                                    <td><?php echo e($result->quantity_all); ?></td>
                                    <td><?php echo e($result->storeName); ?></td>
                                    <td><?php echo e($result->categoryName); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/reports/products_stock_alert/result.blade.php ENDPATH**/ ?>