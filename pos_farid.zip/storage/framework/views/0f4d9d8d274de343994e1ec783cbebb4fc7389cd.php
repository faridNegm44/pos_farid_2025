


<?php $__env->startSection('title'); ?>
    <?php echo e($pageNameAr); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    
    <link href="<?php echo e(url('back')); ?>/assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet">
    
    <link href="<?php echo e(asset('back/assets/file-upload-with-preview.min.css')); ?>" rel="stylesheet" type="text/css" />

    
    <link href="<?php echo e(asset('back/assets/spotlight.min.css')); ?>" rel="stylesheet" type="text/css" />

    <style>
        .pd-sm-40 {
            padding: 40px 40px 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>  
    <script src="<?php echo e(url('back')); ?>/assets/plugins/sweet-alert/jquery.sweet-alert.js"></script>
    <script src="<?php echo e(url('back')); ?>/assets/plugins/sweet-alert/sweetalert.min.js"></script>
    <script src="<?php echo e(url('back')); ?>/assets/js/sweet-alert.js"></script>

    
    <script src="<?php echo e(asset('back/assets/spotlight.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('back/assets/spotlight.min.js')); ?>"></script>

    <!-- fileupload -->
    <script src="<?php echo e(asset('back/assets/file-upload-with-preview.min.js')); ?>"></script>
    <script> new FileUploadWithPreview('file_upload') </script>

    <script>       
        $(document).ready(function () {
            // selectize
            $('selectize').selectize();
            

            // show password or hide
            $('.show_pass').click(function(){
                const password = $("#password");
                const confirmed_password = $("#confirmed_password");

                if(password.attr('type') == 'password' || confirmed_password.attr('type') == 'password'){
                    password.attr('type', 'text');
                    confirmed_password.attr('type', 'text');
                    $('i.fa.fa-eye').removeClass('fa fa-eye').addClass('fa fa-eye-slash');

                }else if(password.attr('type') == 'text' || confirmed_password.attr('type') == 'text'){
                    password.attr('type', 'password');
                    confirmed_password.attr('type', 'password');
                    $('i.fa.fa-eye-slash').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
                }
            });


            // DataTable
            $('#example1').DataTable({
                processing: true,
                serverSide: true,
                ajax: `<?php echo e(url($pageNameEn.'/datatable')); ?>`,
                dataType: 'json',
                columns: [
                    {data: 'id', name: 'id'},
                    {data: 'image', name: 'image'},
                    {data: 'name', name: 'name'},
                    {data: 'email', name: 'email'},
                    {data: 'gender', name: 'gender'},
                    {data: 'phone', name: 'phone'},
                    {data: 'role', name: 'role'},
                    {data: 'status', name: 'status'},
                    {data: 'action', name: 'action', orderable: false},
                ],
                "bDestroy": true,
                language: {
                    sUrl: '<?php echo e(asset("back/assets/js/ar_dt.json")); ?>',
                },
            });
        });

    </script>




    
    <?php echo $__env->make('back.users.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('back.users.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- breadcrumb -->
        <div class="breadcrumb-header justify-content-between">
            <div class="my-auto">
                <div class="d-flex">
                    <h4 class="content-title mb-0 my-auto"><?php echo e($pageNameAr); ?></h4>
                </div>
            </div>
            <div class="d-flex my-xl-auto right-content">
                <div class="pr-1 mb-xl-0">
                    <button type="button" class="btn btn-danger btn-icon ml-2 add" data-effect="effect-scale" data-toggle="modal" href="#exampleModalCenter"><i class="mdi mdi-plus"></i></button>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <?php echo $__env->make('back.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row row-sm">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover text-center text-md-nowrap" id="example1">
                                <thead>
                                    <tr>
                                        <th class="wd-15p border-bottom-0">#</th>
                                        <th class="wd-15p border-bottom-0">الصورة</th>
                                        <th class="wd-15p border-bottom-0" style="width: 20%;">الإسم</th>
                                        <th class="wd-20p border-bottom-0" style="width: 20%;">الإيميل</th>
                                        <th class="wd-20p border-bottom-0">النوع</th>
                                        <th class="wd-15p border-bottom-0">موبايل</th>
                                        <th class="wd-15p border-bottom-0">التراخيص</th>
                                        <th class="wd-10p border-bottom-0">نشط</th>
                                        <th class="wd-25p border-bottom-0">التحكم</th>
                                    </tr>
                                </thead>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/users/index.blade.php ENDPATH**/ ?>