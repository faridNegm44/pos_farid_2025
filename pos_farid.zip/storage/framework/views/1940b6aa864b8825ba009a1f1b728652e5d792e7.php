<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($pageNameAr); ?></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        
        <div class="modal-body">
            <form class="" id="form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="res_id" value=""/>               
                
                <div class="panel panel-primary tabs-style-2">
                  <div class=" tab-menu-heading">
                    <div class="tabs-menu1">
                      <!-- Tabs -->
                      <ul class="nav panel-tabs main-nav-line" style="justify-content: center;margin-bottom: 10px;font-weight: bold;text-decoration: underline;">
                        <li><a href="#general" class="nav-link active" data-toggle="tab">عام</a></li>
                        <li><a href="#images" class="nav-link" data-toggle="tab">الصور</a></li>
                        
                        
                      </ul>
                    </div>
                  </div>
                  <div class="panel-body tabs-menu-body border bg-gray-100" style="padding: 30px 30px 50px;">
                    <div class="tab-content">
                        


                        
                        <div class="tab-pane active" id="general">

                          <h5 style="text-decoration: underline;font-weight: bold;">معلومات أساسية</h5>
                          <div class="row row-xs">
                            <div class="col-lg-4">
                              <label for="app_name" class="main-content-label tx-11 tx-medium tx-gray-600">اسم البرنامج</label>
                              <i class="fas fa-star require_input"></i>
                              <input type="text" class="form-control" placeholder="اسم البرنامج" id="app_name" name="app_name" value="<?php echo e($find['app_name']); ?>">
                              <div>
                                <bold class="text-danger" id="errors-app_name" style="display: none;"></bold>
                              </div>
                            </div>
                                
                            <div class="col-lg-8">
                              <label for="description" class="main-content-label tx-11 tx-medium tx-gray-600">الوصف </label>
                              <input type="text" class="form-control" placeholder="الوصف " id="description" name="description" value="<?php echo e($find['description']); ?>">
                            </div>                         

                            <div class="col-lg-6">
                              <label for="footer_text" class="main-content-label tx-11 tx-medium tx-gray-600">نص الفوتر</label>
                              <input type="text" class="form-control" placeholder="نص الفوتر" id="footer_text" name="footer_text" value="<?php echo e($find['footer_text']); ?>">
                            </div>

                            <div class="col-lg-6">
                              <label for="address" class="main-content-label tx-11 tx-medium tx-gray-600">العنوان</label>
                              <input type="text" class="form-control" placeholder="العنوان" id="address" name="address" value="<?php echo e($find['address']); ?>">
                              <div>
                                <bold class="text-danger" id="errors-address" style="display: none;"></bold>
                              </div>
                            </div>

                          </div>                         


                         

                          <br>
                          <h5 style="text-decoration: underline;font-weight: bold;">معلومات الإتصال</h5>
                          <div class="row row-xs">
                            <div class="col-lg-4">
                              <label for="email" class="main-content-label tx-11 tx-medium tx-gray-600">البريد الإلكتروني</label>
                              <input type="text" class="form-control" placeholder="البريد الإلكتروني" id="email" name="email" value="<?php echo e($find['email']); ?>">
                              <div>
                                <bold class="text-danger" id="errors-email" style="display: none;"></bold>
                              </div>
                            </div>
                            
                            <div class="col-lg-4">
                              <label for="phone1" class="main-content-label tx-11 tx-medium tx-gray-600">رقم التلفون الأول</label>
                              <input type="text" class="form-control" placeholder="رقم التلفون الأول" id="phone1" name="phone1" value="<?php echo e($find['phone1']); ?>">
                              <div>
                                <bold class="text-danger" id="errors-phone1" style="display: none;"></bold>
                              </div>
                            </div>
                            
                            <div class="col-lg-4">
                              <label for="phone2" class="main-content-label tx-11 tx-medium tx-gray-600">رقم التلفون الثاني</label>
                              <input type="text" class="form-control" placeholder="رقم التلفون الثاني" id="phone2" name="phone2" value="<?php echo e($find['phone2']); ?>">
                              <div>
                                <bold class="text-danger" id="errors-phone2" style="display: none;"></bold>
                              </div>
                            </div>
                          </div>
                          
                          
                          
                          
                          <br>
                          <h5 style="text-decoration: underline;font-weight: bold;">معلومات أخري</h5>
                          <div class="col-lg-12">
                            <label for="policy" class="main-content-label tx-11 tx-medium tx-gray-600">سياسة مكتوبة بالريسيت</label>
                            <textarea name="policy" class="form-control" placeholder="سياسة مكتوبة بالريسيت" style="min-height: 100px;"><?php echo $find['policy']; ?></textarea>
                            <div>
                              <bold class="text-danger" id="errors-policy" style="display: none;"></bold>
                            </div>
                          </div>
                          
                          
                        </div>







                        
                        <div class="tab-pane" id="images">
                          <h5 style="text-decoration: underline;font-weight: bold;">الصور</h5>
                          <div class="row row-xs">
                            <div class="col-lg-6">
                              <label for="logo" class="main-content-label tx-11 tx-medium tx-gray-600">صورة لوحة التحكم</label>
                              <i class="fas fa-star require_input"></i>
                              <input type="file" class="form-control" id="logo" name="logo">
                              <input type="hidden"  name="logo_hidden" value="<?php echo e($find['logo']); ?>">
                              <img class="w-100" src="<?php echo e(url('back/images/settings/'.$find['logo'])); ?>" height="300" alt="logo">
                              
                              <div style="padding: 7px 0;">
                                <bold class="text-danger" id="errors-logo" style="display: none;"></bold>
                              </div>
                            </div>
                            
                            <div class="col-lg-6">
                              <label for="fav_icon" class="main-content-label tx-11 tx-medium tx-gray-600">fav icon</label>
                              <i class="fas fa-star require_input"></i>
                              <input type="file" class="form-control"  id="fav_icon" name="fav_icon">
                              <input type="hidden"  name="fav_icon_hidden" value="<?php echo e($find['fav_icon']); ?>">
                              <img class="w-100" src="<?php echo e(url('back/images/settings/'.$find['fav_icon'])); ?>" height="300" alt="fav_icon">
                              
                              <div style="padding: 7px 0;">
                                <bold class="text-danger" id="errors-fav_icon" style="display: none;"></bold>
                              </div>
                            </div>
                          </div>
                        </div>



                      
                        
                        






                        
                        
                        
                        
                        
                        
                        


                    </div>
                  </div>
                </div>
              

                <div class="modal-footer bg bg-dark">                                               
                  <button type="button" id="update" class="btn btn-success">
                      حفظ
                      <span class="spinner-border spinner-border-sm spinner_request2" role="status" aria-hidden="true"></span>
                    </button>
                          
                    <button id="closeModal" type="button" class="btn btn-light" data-dismiss="modal">اغلاق</button>
              </div>

            </form>            
        </div>
      </div>
    </div>
</div>
<?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/settings/form.blade.php ENDPATH**/ ?>