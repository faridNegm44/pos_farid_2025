<div class="main-footer ht-40">
    <div class="container-fluid pd-t-0-f ht-100p">
        <?php echo e(date('Y')); ?> - <?php echo e(GeneralSettingsInfo()->footer_text); ?>

    </div>
</div><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/layouts/footer.blade.php ENDPATH**/ ?>