


<?php $__env->startSection('title'); ?>
    <?php echo e($pageNameAr); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        table.dataTable tbody td.sorting_1{
            background: transparent !important;
        }
        .itemsSearch{
            margin: 0 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>  
    <script>
        $(document).ready(function() {
            $('#example1').DataTable().destroy();
            $('#example1').DataTable({
                "paging": false, // تعطيل التقسيم
                "searching": true, // تفعيل البحث (اختياري)
                "ordering": true, // تفعيل الترتيب (اختياري)
                "info": false, // إخفاء معلومات الصفحة (اختياري)
                "order": [[0, 'desc']]
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- breadcrumb -->
        <div class="breadcrumb-header text-danger" style="display: block !important;text-align: center;margin-bottom: 15px;">
            <h4 class="content-title mb-5 my-auto"><?php echo e($pageNameAr); ?></h4>
        </div>
        <!-- breadcrumb -->

        <div style="margin-bottom: 10px;">
            <div>
                <?php if($treasury): ?>
                    <span class="itemsSearch">الخزينة: <?php echo e($results[0]->treasury_name); ?></span>
                <?php endif; ?>
                <?php if($from): ?>
                    <span class="itemsSearch">تاريخ من: <?php echo e($from); ?></span>
                <?php endif; ?>
                <?php if($to): ?>
                    <span class="itemsSearch">تاريخ الي: <?php echo e($to); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center text-md-nowrap" id="example1">
                        <thead>
                            <tr>
                                <th class="border-bottom-0">تاريخ المصروف</th>
                                <th class="border-bottom-0" >الخزينة</th>
                                <th class="border-bottom-0">وصف المصروف</th>
                                <th class="border-bottom-0">مبلغ المصروف</th>
                                <th class="border-bottom-0" >مستخدم</th>
                                <th class="border-bottom-0">ملاحظات</th>
                            </tr>
                        </thead>                               
                        
                        <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <tr>                                    
                                    <td>
                                        <?php echo e(Carbon\Carbon::parse($result->created_at)->format('d-m-Y')); ?>

                                        <span style="margin: 0 5px;"><?php echo e(Carbon\Carbon::parse($result->created_at)->format('h:i:s a')); ?></span>
                                    </td>
                                    <td><?php echo e($result->treasury_name); ?></td>
                                    <td><?php echo e($result->title); ?></td>
                                    <td><?php echo e($result->amount_money); ?></td>                                    
                                    <td><?php echo e($result->userName); ?></td>
                                    <td><?php echo e($result->notes); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/reports/expenses/result.blade.php ENDPATH**/ ?>