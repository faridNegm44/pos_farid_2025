<script>
    const deleteBtns = document.querySelectorAll(".delete");

    deleteBtns.addEventListener("click", function(){
        for(const deleteBtn of deleteBtns){
            console.log(deleteBtn);
        }
    });


    // $(document).on("click" , "table .delete" ,function(e){
    // e.preventDefault();
    // let res_id = $(this).attr("res_id");
      
    // alertify.confirm('تحذير !!', 'هل أنت متأكد من حذف هذا المستخدم ؟',
    //   function(){
    //       $.ajax({
    //           url: `<?php echo e(url($pageNameEn.'/destroy/${res_id}')); ?>`,
    //           type: "get",
    //           success: function(){
    //               $('#example1').DataTable().ajax.reload( null, false );

    //               alertify.set('notifier','position', 'bottom-right');
    //               alertify.set('notifier','delay', 4);
    //               alertify.error("تم الحذف بنجاح");
    //           },
    //           error: function(){

    //           }
    //       });

    //   },
    //   function(){
    //       alertify.set('notifier','position', 'bottom-right');
    //       alertify.set('notifier','delay', 4);
    //       alertify.error("تم إلغاء الحذف");
    //   });
    // });

</script><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/units/delete.blade.php ENDPATH**/ ?>