

<script>

	// check all input checkbox
	$('#checkAll').click(function () {    
		$('input:checkbox').prop('checked', this.checked);    
	});



	// Focus Search input when click ctrl+/
	$(document).bind('keydown', function(event) {
		if( event.which === 191 && event.ctrlKey ) {
			$(".app-search input").focus();
		}
	});



	// Style To Search input When Focus In And Out
	$(document).ready(function(){
		$(".app-search input").focusin(function(){
			$(this).css({
				background: "#fddc92",
				color: "black",
				fontWeight: "bold",
				transition: "all 0.5s ease-in-out",
			});
		});
		$(".app-search input").focusout(function(){
			$(this).css({
				background: "#f3f3f9",
			});
		});
	});


	// start change modal-header
	let addButton = document.querySelector('.breadcrumb-header .right-content .add');
	// add
	addButton.addEventListener('click', function(){
		document.querySelector('.modal .modal-header .modal-title').innerText = 'إضافة';
		document.querySelector('.modal .modal-footer #save').setAttribute('style', 'display: inline;');
		document.querySelector('.modal .modal-footer #update').setAttribute('style', 'display: none;');
		$('.dataInput').val('');
	});
	// edit
	$("#example1").on("click", ".edit", function(event) {
		document.querySelector('.modal .modal-header .modal-title').innerText = 'تعديل';
		document.querySelector('.modal .modal-footer #save').setAttribute('style', 'display: none;');
		document.querySelector('.modal .modal-footer #update').setAttribute('style', 'display: inline;');
	});
	// end change modal-header



	// select all data in to input type number when focus 
	const inputField = document.querySelector('.numInput');
	inputField.addEventListener('focus', () => {
		inputField.select();
	});
	
	
	
	// change tr background when mouse hover
	// document.querySelectorAll('table tbody tr').addEventListener("mouseover", function() {
	//     this.style.background = "red";
	// });



	$('.dataTables_filter').next().remove();



		
	// file uplodad 
	var firstUpload = new FileUploadWithPreview('file_upload');



	// nice scroll bar
	// $(function() {  
	// 	$("body").niceScroll({
	// 		zindex: 20000,
	// 		scrollspeed: 100,
	// 	});
	// });
</script>



<script>
	$(document).on('input' , '.numValid', function (e) {
		$(this).val($(this).val().replace(/[^0-9.]/g, ''));

		if (($(this).val().split('.').length - 1) > 1)
			$(this).val($(this).val().substring(0, $(this).val().length - 1));
	});
</script>




<script>
	$(document).ready(function () {
		$(".dark_theme").click(function(){
			$("body").toggleClass("dark-theme");
			$(this).css('display', 'none');
			$('.light_theme').css('display', 'block');
		});		
		
		$(".light_theme").click(function(){
			$("body").removeClass("dark-theme");
			$(this).css('display', 'none');
			$('.dark_theme').css('display', 'block');
		});		
	});
</script>







<script>
	let buttons = document.querySelector(".buttons");
	let btn = document.querySelectorAll("span");
	let value = document.getElementById("value");

	for (let i = 0; i < btn.length; i++) {
	btn[i].addEventListener("click", function () {
		if (this.innerHTML == "=") {
		value.innerHTML = eval(value.innerHTML);
		} else {
		if (this.innerHTML == "Clear") {
			value.innerHTML = "";
		} else {
			value.innerHTML += this.innerHTML;
		}
		}
	});
	}
</script>

<?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/layouts/general_scripts.blade.php ENDPATH**/ ?>