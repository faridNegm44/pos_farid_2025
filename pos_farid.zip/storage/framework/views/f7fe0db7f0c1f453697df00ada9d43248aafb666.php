<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title><?php echo e($pageNameAr); ?> <?php echo e($saleBill[0]->id); ?> - <?php echo e($saleBill[0]->clientName); ?> - <?php echo e($saleBill[0]->created_at); ?></title>
  <style>
    body {
      /*font-family: 'Tahoma', sans-serif;*/
      /*font-family: 'Courier New', monospace;*/
      margin: 20px;
      margin-bottom: 35px;
      color: #000;
      font-weight: bold;

    }

    /*td:nth-child(3),
    td:nth-child(4),
    td:nth-child(5),
    th:nth-child(3),
    th:nth-child(4),
    th:nth-child(5) {
        font-family: 'Roboto Mono', monospace;
    }*/

    .header, .customer_info, .invoice_info {
      margin-bottom: 10px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #000;
      padding-bottom: 3px;
    }

    .header .logo img{
      width: 50px;
      height: 50px;
      background-color: #ddd;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 14px;
    }

    .header .place_info {
      flex: 1;
      text-align: center;
      margin: 0 5px;
    }

    .place_info h2 {
      margin: 0;
      font-size: 18px;
      text-decoration: underline;
      margin-bottom: 4px;
    }

    .place_info p {
      margin: 1px 0;
      font-size: 11px;
    }

    .customer_info, .invoice_info {
      font-size: 12px;
      /*border: 1px dashed #000;*/
      padding: 0 8px;
    }

    .invoice_info {
      display: flex;
      justify-content: space-between;
      font-weight: bold;
      border: 1px dashed #000;
      border-radius: 5px;
      padding: 4px 8px;
    }
    
    .date_info {
      font-weight: bold;
      font-size: 9px;
      text-align: center;
      padding-top: 5px;
      font-family: 'Roboto Mono', monospace;
    }

    .table_info table,
    .table_info th,
    .table_info td {
      border: 1px solid #000;
      border-collapse: collapse;
      text-align: center;
      font-size: 11px;
      padding: 1px 3px;
    }

    .table_info thead th {
      background-color: #dee2e6;
    }

    .totals_section {
      margin-top: 15px;
      font-size: 14px;
    }

    .totals_section table {
      width: 100%;
      /*border-collapse: collapse;*/
    }

    .totals_section td {
      /*padding: 4px 8px;*/
      border: 1px solid #000;
      text-align: right;
    }

    .totals_section td.label {
      font-weight: bold;
      font-size: 11px;
    }

    .totals_section td.value {
      font-size: 13px;
      font-weight: bold;
    }

    .policy_section {
      margin-top: 15px;
      border: 1px dashed #000;
      border-radius: 8px;
      padding: 0 8px;
      font-size: 11.5px;
      line-height: 1.5;
    }
    
    .footer_section {
        text-align: center;
        margin-top: 10px;
        /*border: 1px dashed #000;*/
        /*padding: 0 8px;*/
        font-size: 12px;
    }

    .company_info {
      margin-top: 15px;
      text-align: center;
      font-size: 8px;
      border-top: 2px solid #000;
      border-bottom: 1px solid #ccc;
      padding: 4px 0;
    }

    .table_info thead th {
        background-color: #a5a5a5 !important;
    }

    .totals_section .final_total {
    background-color: #a5a5a5 !important;
    }
    
    @media print {
      body {
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }

      @page {
        margin: 5px;
      }

    body {
      margin: 5px !important;
      padding: 5px !important;
    }

      .table_info thead th {
        background-color: #a5a5a5 !important;
      }

      .totals_section .final_total {
        background-color: #a5a5a5 !important;
      }

      .header {
        page-break-before: avoid;
      }
    }
  </style>
</head>
<body>

  <!-- Header -->
  <div class="header">
    
    <div class="place_info">
      <h2><?php echo e(GeneralSettingsInfo()->app_name); ?></h2>
      <p><?php echo e(GeneralSettingsInfo()->address); ?></p>
      <p><?php echo e(GeneralSettingsInfo()->phone1); ?> - <?php echo e(GeneralSettingsInfo()->phone2 ?? GeneralSettingsInfo()->phone1); ?></p>
    </div>
  </div>

  <!-- Customer Info -->
  <div class="customer_info">
    <span>اسم العميل: <?php echo e($saleBill[0]->clientName); ?></span>
    <br />
    <span>عنوان العميل: <?php echo e($saleBill[0]->clientAddress); ?></span>
    <br />
    <span>تليفون العميل: <?php echo e($saleBill[0]->clientPhone); ?></span>
    <br />
  </div>

  <!-- Invoice Info -->
  <div class="invoice_info">
    <div>رقم الفاتورة: <?php echo e($saleBill[0]->id); ?></div>
    <div>عدد الأصناف: <?php echo e(display_number( $saleBill[0]->count_items )); ?></div>
  </div>

  <!-- Table -->
  <div class="table_info">
    <table style="width: 100%;">
        <thead>
          <tr>
            <th>الصنف</th>
            <th>الوحدة</th>
            <th>الكمية</th>
            <th>السعر</th>
            <th>الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $saleBill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($product->productName); ?></td>
              <td><?php echo e($product->unitName); ?></td>
              <td><?php echo e(display_number( $product->product_bill_quantity )); ?></td>
              <td><?php echo e(display_number( $product->sell_price_small_unit )); ?></td>
              <td><?php echo e(display_number( $product->productTotalAfter )); ?></td>
            </tr>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>      
  </div>

  <!-- Totals -->
  <div class="totals_section">
    <table>
      <tr>
        <td class="label">الإجمالي قبل</td>
        <td class="value"><?php echo e(display_number( $saleBill[0]->total_bill_before )); ?> جنية</td>
      </tr>
      <?php if($saleBill[0]->extra_money): ?>
        <tr>
          <td class="label">مصاريف اضافية</td>
          <td class="value"><?php echo e(display_number( $saleBill[0]->extra_money )); ?> جنية</td>
        </tr>
      <?php endif; ?>
      <?php if($saleBill[0]->bill_discount): ?>
        <tr>
          <td class="label">قيمة الخصم</td>
          <td class="value"><?php echo e(display_number( $saleBill[0]->bill_discount )); ?> جنية</td>
        </tr>
      <?php endif; ?>
      <?php if($saleBill[0]->bill_tax): ?>
        <tr>
          <td class="label">الضريبة</td>
          <td class="value"><?php echo e(display_number( $saleBill[0]->bill_tax )); ?> %</td>
        </tr>
      <?php endif; ?>
      <tr>
        <td class="label final_total" style="font-size: 14px;">الإجمالي بعد</td>
        <td class="value" style="font-size: 18px;font-weight: bold;"><?php echo e(display_number( $saleBill[0]->total_bill_after )); ?> جنية</td>
      </tr>
    </table>
  </div>

  <div class="date_info">
    <div>تاريخ الفاتورة: <?php echo e(\Carbon\Carbon::parse($saleBill[0]->created_at)->format('Y-m-d h:i:s a')); ?></div>
    <div>تاريخ الطباعة: <?php echo e(date('Y-m-d h:i:s a')); ?></div>
  </div>

  <!-- Policy -->
  <?php if(GeneralSettingsInfo()->policy): ?>
    <div class="policy_section">
        <?php echo GeneralSettingsInfo()->policy; ?>

    </div>
  <?php endif; ?>
  
  <?php if(GeneralSettingsInfo()->footer_text): ?>
    <div class="footer_section">
        <?php echo e(GeneralSettingsInfo()->footer_text); ?>

    </div>
  <?php endif; ?>

  <!-- Company Info -->
  <div class="company_info">
    كيوبكس تك للبرمجيات
    <strong>01117903055 - 01012775704</strong>
  </div>

</body>
</html>
<?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/sales/print_receipt.blade.php ENDPATH**/ ?>