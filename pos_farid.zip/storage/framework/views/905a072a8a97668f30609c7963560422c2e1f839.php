<!-- main-header -->
<div class="main-header nav nav-item hor-header">
    <div class="container-fluid" style="width: 100% !important;">
        <div class="main-header-left ">
            <a class="animated-arrow hor-toggle horizontal-navtoggle"><span></span></a>
            <a class="header-brand" href="<?php echo e(url('')); ?>">
                <img src="<?php echo e(asset('back')); ?>/assets/img/brand/logo-white.png" class="desktop-dark">
                <img src="<?php echo e(asset('back')); ?>/assets/img/brand/logo.png" class="desktop-logo">
                <img src="<?php echo e(asset('back')); ?>/assets/img/brand/favicon.png" class="desktop-logo-1">
                <img src="<?php echo e(asset('back')); ?>/assets/img/brand/favicon.png" class="desktop-logo-dark">
            </a>         

            <div class="horizontal-main header-layout d-none d-md-flex d-lg-flex">
                <div class="horizontal-mainwrapper container clearfix">
                    <nav class="horizontalMenu clearfix"><div class="horizontal-overlapbg"></div>
                        <ul class="horizontalMenu-list">
                            <li aria-haspopup="true"><span class="horizontalMenu-click"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span>
                                <a class="sub-icon" href="#">
                                <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                                
                                إختصارات <i class="fe fe-chevron-down horizontal-icon"></i></a>
                                <ul class="sub-menu">
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="">تعريفات</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('financialYears')); ?>" class="slide-item">السنوات المالية</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('stores')); ?>" class="slide-item">المخازن</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('financial_treasury')); ?>" class="slide-item">الخزائن المالية</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('units')); ?>" class="slide-item">وحدات الأصناف</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('treasury_bills/create')); ?>">الحسابات</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills')); ?>" class="slide-item">معاملات الخزينة المالية</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills/create')); ?>" class="slide-item">أجراء معاملة في الخزينة المالية</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('transfer_between_storages')); ?>" class="slide-item">التحويل من خزنة لأخري</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('expenses')); ?>" class="slide-item">المصروفات</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('expenses/report')); ?>" class="slide-item">تقرير عن المصروفات</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills/report')); ?>" class="slide-item">تقرير عن حركة الخزائن المالية</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('clients')); ?>">العملاء</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('clients')); ?>" class="slide-item">العملاء</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('clients/report')); ?>" class="slide-item">تقرير عن حركة عميل</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('clients/report/account_statement')); ?>" class="slide-item">كشف حساب عميل</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('taswea_client_supplier')); ?>" class="slide-item">تسوية رصيد عميل</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('suppliers')); ?>">الموردين</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers')); ?>" class="slide-item">الموردين</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers/report')); ?>" class="slide-item">تقرير عن حركة مورد</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers/report/account_statement')); ?>" class="slide-item">كشف حساب مورد</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('taswea_client_supplier')); ?>" class="slide-item">تسوية رصيد مورد</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('products')); ?>">الأصناف</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('products')); ?>" class="slide-item">قائمة الأصناف</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('products/report/stock_alert')); ?>" class="slide-item">كشكول النواقص</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('productsCategories')); ?>" class="slide-item">أقسام الأصناف</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('units')); ?>" class="slide-item">وحدات الأصناف</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('taswea_products')); ?>" class="slide-item">تسوية كميات الأصناف</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('sales/create')); ?>">المبيعات</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('sales')); ?>" class="slide-item">قائمة المبيعات</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('sales/create')); ?>" class="slide-item">فاتورة مبيعات جديدة</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('sales/return')); ?>" class="slide-item">قائمة مرتجعات البيع</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('purchases/create')); ?>">المشتريات</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('purchases')); ?>" class="slide-item">قائمة المشتريات</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('purchases/create')); ?>" class="slide-item">فاتورة مشتريات جديدة</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('purchases/return')); ?>" class="slide-item">قائمة مرتجعات الشراء</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="">تقارير</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('suppliers/report')); ?>" class="slide-item">تقرير عن حركة مورد</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('clients/report')); ?>" class="slide-item">تقرير عن حركة عميل</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('expenses/report')); ?>" class="slide-item">تقرير عن المصروفات</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('treasury_bills/report')); ?>" class="slide-item">تقرير عن حركة الخزائن المالية</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('products/report')); ?>" class="slide-item">تقرير عن حركة صنف</a></li>
                                            <li aria-haspopup="true"><a href="<?php echo e(url('products/report/stock_alert')); ?>" class="slide-item">تقرير عن كشكول النواقص</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('users')); ?>">مستخدمين النظام</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('users')); ?>" class="slide-item">مستخدمين النظام</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li aria-haspopup="true" class="sub-menu-sub"><span class="horizontalMenu-click02"><i class="horizontalMenu-arrow fe fe-chevron-down"></i></span><a href="<?php echo e(url('settings')); ?>">الإعدادات العامة</a>
                                        <ul class="sub-menu">
                                            <li aria-haspopup="true"><a href="<?php echo e(url('settings')); ?>" class="slide-item">الإعدادات العامة</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            
            
            
        </div><!-- search -->
    

        <div class="main-header-right">
            
            <div>
                <a type="button" style="font-size: 18px;margin: 5px;" data-bs-toggle="tooltip" title="الالة الحاسبة" data-effect="effect-scale" data-toggle="modal" href=".calc">
                    <i class="mdi mdi-calculator bg-dark text-white product-icon" style="padding: 0 5px;border-radius: 50%;"></i>
                </a>
                
                <a href="<?php echo e(url('sales/create')); ?>" style="font-size: 18px;margin: 5px;" data-bs-toggle="tooltip" title="فاتورة بيع جديدة">
                    <i class="mdi mdi-cart-outline bg-success-gradient text-white product-icon" style="padding: 0 5px;border-radius: 50%;"></i>
                </a>

                <a href="<?php echo e(url('purchases/create')); ?>" style="font-size: 18px;margin: 5px;" data-bs-toggle="tooltip" title="فاتورة شراء جديدة">
                    <i class="mdi mdi-cart-plus bg-danger-gradient text-white product-icon" style="padding: 0 5px;border-radius: 50%;"></i>
                </a>

                <a href="<?php echo e(url('treasury_bills/create')); ?>" style="font-size: 18px;margin: 5px;" data-bs-toggle="tooltip" title="أجراء معاملة في الخزينة المالية">
                    <i class="mdi mdi-cash-multiple bg-primary-gradient text-white product-icon" style="padding: 0 5px;border-radius: 50%;"></i>
                </a>

                
                
            </div>


            
            
            <div class="nav-item dark_theme">
                <a class="new nav-link full-screen-link"style="font-size: 25px;cursor: pointer;">
                    <i class="mdi mdi-lightbulb-on"></i>    
                </a>
            </div>
            
            <div class="nav-item light_theme" style="display: none;">
                <a class="new nav-link full-screen-link" style="font-size: 25px;color: #eec706;cursor: pointer;">
                    <i class="mdi mdi-lightbulb-on-outline"></i>    
                </a>
            </div>
            
            
            <div class="nav nav-item  navbar-nav-right ml-auto">
                



                

                <div class="nav-item full-screen fullscreen-button">
                    <a class="new nav-link full-screen-link" href="#"><svg xmlns="http://www.w3.org/2000/svg" class="header-icon-svgs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg></a>
                </div>

                <div class="dropdown main-profile-menu nav nav-item nav-link">
                    <a class="profile-user d-flex" href="#"><img alt="" src="<?php echo e(asset('back/images/users/'.authUserInfo()->image)); ?>"></a>
                    <div class="dropdown-menu">
                        <div class="main-header-profile bg-primary p-3">
                            <div class="d-flex wd-100p">
                                <div class="main-img-user"><img alt="" src="<?php echo e(asset('back/images/users/'.authUserInfo()->image)); ?>" class=""></div>
                                <div class="mr-3 my-auto">
                                    <h6><?php echo e(authUserInfo()->name); ?></h6>
                                    <span><?php echo e(authUserInfo()->role); ?></span>
                                </div> 
                            </div>
                        </div>
                        <a class="dropdown-item" href="profile.html"><i class="bx bx-user-circle"></i>Profile</a>
                        <a class="dropdown-item" href="editprofile.html"><i class="bx bx-cog"></i> Edit Profile</a>
                        <a class="dropdown-item" href="mail-compose.html"><i class="bx bxs-inbox"></i>Inbox</a>
                        <a class="dropdown-item" href="mail.html"><i class="bx bx-envelope"></i>Messages</a>
                        <a class="dropdown-item" href="mail-settings.html"><i class="bx bx-slider-alt"></i> Account Settings</a>
                        <a class="dropdown-item text-danger" href="<?php echo e(url('logout')); ?>"><i class="bx bx-log-out"></i> تسجيل خروج</a>
                    </div>
                </div>

                <div class="dropdown main-header-message right-toggle">
                    <a class="nav-link pr-0" data-toggle="sidebar-left" data-target=".sidebar-left">
                        <svg xmlns="http://www.w3.org/2000/svg" class="header-icon-svgs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /main-header --><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/layouts/header.blade.php ENDPATH**/ ?>