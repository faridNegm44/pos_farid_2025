<div class="row" style="margin-bottom: 10px;">
    <div class="col-xs-6 text-left">
        <img src="<?php echo e(asset('back/images/settings/logo.png')); ?>" alt="" style="width: 150px;height: 50px;margin-top: -12px; margin-bottom: 7px;">
        <div>
            <span><?php echo e(GeneralSettingsInfo()->phone1); ?></span> 
            <span style="margin: 0 10px;"><?php echo e(GeneralSettingsInfo()->phone2 ?? ''); ?></span>
        </div>
    </div>

    <div class="col-xs-6 text-right">
        <div style="padding-top: 10px;">
            <div><?php echo e(GeneralSettingsInfo()->address); ?></div>
            
            <div>المستخدم: <?php echo e(auth()->user()->name); ?></div>
            <?php echo e(date('d-m-Y')); ?> <span style="font-size: 16px;font-weight: bold;"><?php echo e(date('h:i a')); ?></span>
        </div>
    </div>
    
</div><?php /**PATH E:\xampp8212\htdocs\pos_farid\resources\views/back/layouts/header_report.blade.php ENDPATH**/ ?>